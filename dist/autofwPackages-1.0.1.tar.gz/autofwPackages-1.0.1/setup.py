import setuptools

# with open('requirements.txt') as f:
#     install_requires = f.read().splitlines()

setuptools.setup(
    name='autofwPackages',
    version='1.0.1',
    description="this is trial run autofw packages...",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    # install_requires=install_requires
)
